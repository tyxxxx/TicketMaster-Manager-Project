var express = require('express')
var router = express.Router()
const geohash = require('ngeohash')
const { get, post } = require('axios')
const axios = require('axios')
const SpotifyWebApi = require('spotify-web-api-node')
const spotifyClientId='60ab729dae604853a79bbd819b18e0da'
const spotifySecretKey='602ac028012b44acbcc2c102d4b1a0cd'

const spotifyApi = new SpotifyWebApi({
  clientId: spotifyClientId,
  clientSecret: spotifySecretKey,

})
const SEGMENT_IDS = {
  Music: 'KZFzniwnSyZfZ7v7nJ',
  Sports: 'KZFzniwnSyZfZ7v7nE',
  Arts: 'KZFzniwnSyZfZ7v7na',
  Theatre: 'KZFzniwnSyZfZ7v7na',
  Film: 'KZFzniwnSyZfZ7v7nn',
  Miscellaneous: 'KZFzniwnSyZfZ7v7n1',
}
router.get('/suggest', async(req, res) => {

  try {
    const { data } = await get(
      'https://app.ticketmaster.com/discovery/v2/suggest',
      {
        params: {
          apikey: 'vu7g5oyBqql5YmRuHrRq2uaKMdMuttBD',
          keyword: req.query.keyword || '',
        },
      },
    )
    res.json(data)
  } catch (error) {
    console.error(error)
    res.status(500).send('Server Error')
  }
})

router.get('/events', async(req, res) => {

  try {
    const { data } = await get(
      'https://app.ticketmaster.com/discovery/v2/events.json',
      {
        params: {
          apikey: 'vu7g5oyBqql5YmRuHrRq2uaKMdMuttBD',
          keyword: req.query.keyword || '',
          radius: req.query.distance || '10',
          unit: 'miles',
          segmentId: SEGMENT_IDS[req.query.category],
          geoPoint: geohash.encode(
            req.query.lat || '34.0522342', //'40.4251',
            req.query.lng || '-118.2436849',//'74.021',
            7,
          ),

        },

      },
    )
    res.json(data)
  } catch (error) {
    console.error(error)
    res.status(500).send('Server Error')
  }
})
router.get('/detail', async(req, res) => {
  try {
    if (!req.query.id) {
      res.status(400).send('Missing event id')
    }
    const { data } = await get(
      `https://app.ticketmaster.com/discovery/v2/events/${req.query.id}.json`,
      {
        params: {
          apikey: 'vu7g5oyBqql5YmRuHrRq2uaKMdMuttBD',
        },

      },
    )
    res.json(data)
  } catch (error) {
    console.error(error)
    res.status(500).send('Server Error')
  }
})

router.get('/artist', async(req, res) => {
  const artist = req.query.artist;
  spotifyApi.clientCredentialsGrant()
  .then(data => {
    spotifyApi.setAccessToken(data.body['access_token']);
    spotifyApi.search(artist,['artist','album'],)
    .then(async data => {
      res.json({
        ...data.body,
        albums: (await spotifyApi.getArtistAlbums(data.body.artists.items[0].id)).body,
      })
    })
    .catch(err => {
      console.log(err);
      res.status(500).json({ error: 'Error searching for artist' });
    });

  })
  .catch(error => {
    console.log('Error getting access token:', error);
  });


})

router.get('/venue', async(req, res) => {
  try {
    const { data } = await get(
      `https://app.ticketmaster.com/discovery/v2/venues`,
      {
        params: {
          apikey: 'vu7g5oyBqql5YmRuHrRq2uaKMdMuttBD',
          keyword: req.query.keyword || '',
        },
      },
    )
    res.json(data)
  } catch (error) {
    console.error(error)
    res.status(500).send('Server Error')
  }
})

module.exports = router
