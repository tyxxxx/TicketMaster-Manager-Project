import './App.css'
import { useEffect } from 'react'
import {
  createBrowserRouter,
  Link, Outlet,
  RouterProvider,
  useNavigate,
} from 'react-router-dom'

function App({ children }) {
  const navigate = useNavigate()
  useEffect(() => {
    if (window.location.pathname === '/') {
      navigate('/search')
    }
  })
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div className="container-fluid justify-content-end">

          <div className=" navbar-expand" id="navbarNav">
            <ul className="navbar-nav ms-auto">

              <li className="nav-item">
                <Link
                  className="nav-link active"
                  aria-current="page"
                  to="/"
                >Search</Link>
              </li>
              <li className="nav-item">
                <Link
                  className="nav-link"
                  aria-current="page"
                  to="/favorites"
                >Favorites
                </Link></li>

            </ul>
          </div>
        </div>
      </nav>
      <div>
        {<Outlet></Outlet>}
      </div>
    </div>
  )
}

export default App
