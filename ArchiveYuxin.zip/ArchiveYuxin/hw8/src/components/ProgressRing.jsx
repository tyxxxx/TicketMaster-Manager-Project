import { useEffect, useRef } from 'react'

export default (props) => {
  useEffect(() => {
    setProgress(props.percent)
  }, [props.percent])
  const circleRef = useRef(null)

  function setProgress(percent) {
    const radius = circleRef.current.r.baseVal.value
    const circumference = radius * 2 * Math.PI
    const offset = circumference - percent / 100 * circumference
    circleRef.current.style.strokeDasharray = `${circumference} ${circumference}`
    circleRef.current.style.strokeDashoffset = `${circumference}`
    circleRef.current.style.strokeDashoffset = offset
  }

  return <div className={'progressContainer'}>
    <span className={'progress__text'}>{props.percent}</span>
    <svg
      className="progress-ring"
      width="60"
      height="60"
    >
      <circle
        ref={circleRef}
        className="progress-ring__circle"
        stroke="red"
        fill="transparent"
        r="26"
        cx="30"
        cy="30"
      />
    </svg>
  </div>

}
