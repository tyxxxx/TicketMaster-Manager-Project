import { useEffect, useState } from 'react'
const getClass = (classification) => {
  const segment = classification?.segment?.name
    ? classification?.segment?.name != 'Undefined'
      ? classification?.segment?.name
      : ''
    : ''
  const genre = classification?.genre?.name
    ? classification?.genre?.name != 'Undefined'
      ? classification?.genre?.name
      : ''
    : ''
  const subGenre = classification?.subGenre?.name
    ? classification?.subGenre?.name != 'Undefined'
      ? classification?.subGenre?.name
      : ''
    : ''
  const type = classification?.type?.name
    ? classification?.type?.name != 'Undefined'
      ? classification?.type?.name
      : ''
    : ''
  const subType = classification?.subType?.name
    ? classification?.subType?.name != 'Undefined'
      ? classification?.subType?.name
      : ''
    : ''
  //, type, subType
  return [genre, subGenre, segment, type, subType].filter(item => item)
  .join(' | ')
}

export default () => {
  const [data, setData] = useState([])
  useEffect(() => {
    setData(localStorage.getItem('liked')
      ? JSON.parse(localStorage.getItem('liked'))
      : [],
    )
  }, [])
  return data.length ? <div className={'container'}>
    <h1 className={'text-center text-white'}>List of your favorite events</h1>
    <div className="row justify-content-center ">
      <div className="col-md-10">
        <table className="table table-dark table-striped">
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Date/Time</th>
            <th scope="col">Event</th>
            <th scope="col">Category</th>
            <th scope="col">Venue</th>
            <th scope="col">Favorite</th>
          </tr>
          </thead>
          <tbody>
          {
            data.map((event, idx) => {
              return <tr
                key={event.id}
              >
                <td>{idx + 1}</td>
                <td>{event.dates.start.localDate} {event.dates.start.localTime}</td>
                <td width={'w-100'}>{event.name}</td>
                <td>{
                  event.classifications.map((classification) => {
                    return <div key={classification.segment.id}>
                      {getClass(classification)}
                    </div>
                  })
                }
                </td>
                <td>{event._embedded.venues[0].name}</td>
                <td>
                  <button
                    className={'btn btn-danger'}
                    onClick={() => {
                      const data = localStorage.getItem('liked') ? JSON.parse(
                        localStorage.getItem('liked')) : []
                      const newData = data.filter(item => item.id !== event.id)
                      localStorage.setItem('liked', JSON.stringify(newData))
                      setData(newData)
                      alert('Removed from favorites!')
                    }}
                  >Remove
                  </button>
                </td>

              </tr>
            })
          }
          </tbody>
        </table>
      </div>
    </div>
  </div> : <div className="container">
    <div className="row justify-content-center">
      <div className="col-md-10">
        <div className="alert alert-warning" role="alert">
          No favorite events to show.
        </div>
      </div>
    </div>
  </div>
}
