import {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react'
import ProgressRing from '../../components/ProgressRing'
import GoogleMapReact from 'google-map-react'

const debounce = (func, wait, immediate) => {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      timeout = null
      if (!immediate) func(...args)
    }
    const callNow = immediate && !timeout
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
    if (callNow) func(...args)
  }
}
const gmAPI = 'AIzaSyCxMDQd7bL84qZidWOdbTnNoVzlEW1H9oo'
const getGenre = (classification) => classification?.segment?.name
  ? classification?.segment?.name != 'Undefined'
    ? classification?.segment?.name
    : ''
  : ''

const getClass = (classification) => {
  const segment = classification?.segment?.name
    ? classification?.segment?.name != 'Undefined'
      ? classification?.segment?.name
      : ''
    : ''
  const genre = classification?.genre?.name
    ? classification?.genre?.name != 'Undefined'
      ? classification?.genre?.name
      : ''
    : ''
  const subGenre = classification?.subGenre?.name
    ? classification?.subGenre?.name != 'Undefined'
      ? classification?.subGenre?.name
      : ''
    : ''
  const type = classification?.type?.name
    ? classification?.type?.name != 'Undefined'
      ? classification?.type?.name
      : ''
    : ''
  const subType = classification?.subType?.name
    ? classification?.subType?.name != 'Undefined'
      ? classification?.subType?.name
      : ''
    : ''
  //, type, subType
  return [genre, subGenre, segment, type, subType].filter(item => item)
  .join(' | ')
}
export default () => {
  const [keyword, setKeyword] = useState('')
  const [distance, setDistance] = useState(10)
  const [location, setLocation] = useState('')
  const [autoDetect, setAutoDetect] = useState(false)
  const [keywordList, setKeywordList] = useState([])
  const [showDetail, setShowDetail] = useState(false)
  const [showSearch, setShowSearch] = useState(false)
  const [category, setCategory] = useState('Default')
  const [tableData, setTableData] = useState(null)
  const [geo, setGeo] = useState({ lat: '', lng: '' })
  const [detailData, setDetailData] = useState(null)
  const resultDetailRef = useRef(null)

  useEffect(() => {
    if (autoDetect) {
      setLocation('')
      setGeo({ lat: '', lng: '' })
    }
  }, [autoDetect])
  const handleClickRow = (e) => {
    setShowDetail(true)
    setDetailData(e)
    setTimeout(() => resultDetailRef.current.getEvent())
  }
  const getLocation = async(location) => {
    const d = await fetch(
      'https://maps.googleapis.com/maps/api/geocode/json?address=' + (location || 'Los angeles') + '&key=' + gmAPI)
    const json = await d.json()
    return json.results?.[0]?.geometry?.location

  }
  const reset = () => {
    setKeyword('')
    setDistance(10)
    setLocation('')
    setAutoDetect(false)
    setKeywordList([])
    setGeo({ lat: '', lng: '' })
    setTableData(null)
    setShowDetail(false)
    setDetailData(null)
    setCategory('Default')
    setShowSearch(false)
    setShowDetail(false)
  }
  const search = async(e) => {
    e.preventDefault()
    setShowDetail(false)
    setTableData(null)
    setShowSearch(false)
    let c = category === 'Default' ? '' : category
    let g
    if (autoDetect) {
      g = await getLocation()
    } else {
      g = await getLocation(location)
    }

    if (!g) {
      setTableData(null)
      setShowSearch(true)
      return
    }
    const { lng, lat } = g
    const data = await fetch('http://localhost:3001/api/events?keyword=' + keyword + '&distance=' + distance + '&lng=' + lng + '&lat=' + lat + '&category=' + c)
    .then(res => res.json())
    setTableData(data && data._embedded && data._embedded.events && data._embedded.events.length > 0
      ? {
        ...data,
        _embedded: {
          ...data._embedded,
          events: data._embedded.events.sort((
            a,
            b,
          ) => new Date(a.dates.start.dateTime).getTime() - new Date(b.dates.start.dateTime).getTime()),
        },
      }
      : null)
    setShowSearch(true)
  }
  const handleKeyChange =debounce(async(e) => {
      setKeyword(e.target.value)
      const data = await fetch('http://localhost:3001/api/suggest?keyword=' + e.target.value)
      .then(res => res.json())
      setKeywordList(data._embedded?.attractions.map(item => item.name) || [])
    }
  ,1000)
  return <div style={{ position: 'relative' }}>
    {<div className="container p-3">
      <div className="row justify-content-center">
        <div
          className="col-md-6 p-4 rounded" style={{
          backgroundColor: 'rgba(0,0,0,0.45)',
        }}
        >
          <h2 className="text-center text-white">Events Search</h2>
          <form onSubmit={search}>
            <div className="form-group">
              <label className={'text-white'} htmlFor="keyword">Keyword:<span
                style={{ color: 'red' }}
              >*</span></label>
              <input
                onChange={handleKeyChange}
                type="text"
                className="form-control"
                id="keyword"
                name="keyword"
                required
                list="hints"
                autoComplete={'off'}
              />
              <datalist id="hints">
                {
                  keywordList.map(item => <option
                    value={item}
                    label={item}
                    key={item}
                  />)
                }
              </datalist>
            </div>
            <div className="form-row">
              <div className="form-group col-md-6">
                <label
                  className={'text-white'}
                  htmlFor="distance"
                >Distance:</label>
                <input
                  value={distance}
                  onChange={e => setDistance(e.target.value)}
                  type="number"
                  className="form-control"
                  id="distance"
                  name="distance"
                />
              </div>
              <div className="form-group col-md-6">
                <label
                  className={'text-white'}
                  htmlFor="category"
                >Category:<span style={{ color: 'red' }}>*</span></label>
                <select
                  className="form-control "
                  id="category"
                  name="category"
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  required
                >
                  <option value="Default">Default</option>
                  <option value="Music">Music</option>
                  <option value="Sports">Sports</option>
                  <option value="Arts">Arts & Theatre</option>
                  <option value="Film">Film</option>
                  <option value="Miscellaneous">Miscellaneous</option>
                </select>
              </div>
            </div>
            <div className="form-group">
              <label className={'text-white'} htmlFor="location">Location:<span
                style={{ color: 'red' }}
              >*</span></label>
              {<input
                type="text"
                className="form-control"
                id="location"
                value={location}
                onChange={e => setLocation(e.target.value)}
                name="location"
                required={autoDetect ? false : true}
              />}
              <div className="form-check">
                <input
                  onChange={e => setAutoDetect(e.target.checked)}
                  checked={autoDetect}
                  type="checkbox"
                  className="form-check-input"
                  id="auto-detect"
                  name="auto-detect"
                />
                <label
                  className="text-white form-check-label"
                  htmlFor="auto-detect"
                >Auto-detect
                  Your Location</label>
              </div>
            </div>
            <div className="form-group text-center">
              <button
                type="submit"
                className="mr-3 btn btn-danger"
              >SUBMIT
              </button>
              <button
                type="reset"
                className="btn btn-primary"
                onClick={reset}
              >CLEAR
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>}
    {
      showDetail && <ResultDetail
        ref={resultDetailRef}
        data={detailData}
        keyword={keyword}
        back={() => setShowDetail(false)}
      />
    }
    {showSearch && !showDetail && <SearchResults
      clickedRow={handleClickRow}
      data={tableData}
    ></SearchResults>}
  </div>
}

const SearchResults = ({
  data,
  clickedRow,
}) => {
  const handleEventClick = (event) => {
    clickedRow(event)
  }
  return data && data._embedded && data._embedded.events && data._embedded.events.length > 0
    ? (<div className="container">
      <div className="row justify-content-center ">
        <div className="col-md-10">
          <table className="table  table-dark table-striped">
            <thead>
            <tr>
              <th scope="col">Date/Time</th>
              <th scope="col">Icon</th>
              <th scope="col">Event</th>
              <th scope="col">Genre</th>
              <th scope="col">Venue</th>
            </tr>
            </thead>
            <tbody>
            {
              data._embedded.events.map((event) => {
                return <tr
                  onClick={() => handleEventClick(event)}
                  key={event.id}
                >
                  <td className={'text-center'}>{event.dates.start.localDate} {event.dates.start.localTime}</td>
                  <td>
                    <img
                      style={{ width: '100px' }}
                      src={event.images && event.images.length > 0 && event.images[0].url}
                    />
                  </td>
                  <td width={'w-100'}>{event.name}</td>
                  <td>{getGenre(event.classifications[0])}</td>
                  <td>{event._embedded.venues[0].name}</td>
                </tr>
              })
            }
            </tbody>
          </table>
        </div>
      </div>
    </div>)
    : (<div className="container">
      <div className="row justify-content-center">
        <div className="col-md-10">
          <div className="alert alert-warning" role="alert">
            No results available.
          </div>
        </div>
      </div>
    </div>)
}

const ResultDetail = forwardRef((props, ref) => {
  const [tab, setTab] = useState(3)
  const eventRef = useRef(null)
  const artistRef = useRef(null)
  const venueRef = useRef(null)
  const [liked, setLiked] = useState(false)
  const [events, setEvent] = useState(null)

  useEffect(() => {
    const data = localStorage.getItem('liked')
      ? JSON.parse(localStorage.getItem('liked'))
      : []
    setLiked(data.some(item => item.id === props.data.id))
  }, [])
  const getEvent = () => {
    setTab(1)
    setTimeout(() => eventRef.current.getData(props.data.id))
  }
  const getArtist = () => {
    const eventData = eventRef?.current?.getRefData() || events
    setEvent(eventData)
    const isMusic = getGenre(eventData.classifications[0]).includes('Music')
    setTab(2)
    setTimeout(() => artistRef.current.getData(isMusic ? eventData : null))
  }
  const getVenue = () => {
    setTab(3)
    setTimeout(() => venueRef.current.getData(props.data._embedded.venues[0].name))
  }
  useImperativeHandle(ref, () => ({
    getEvent,
  }))
  const handleLike = (now, item) => {
    if (now) {
      const data = localStorage.getItem('liked')
        ? JSON.parse(localStorage.getItem('liked'))
        : []

      data.push(item)
      localStorage.setItem('liked', JSON.stringify(data))
      setLiked(true)
      window.alert('Event Added to Favorites!')
    } else {
      const data = localStorage.getItem('liked')
        ? JSON.parse(localStorage.getItem('liked'))
        : []

      data.splice(data.indexOf(item), 1)
      localStorage.setItem('liked', JSON.stringify(data))
      setLiked(false)
      window.alert('Event Removed from Favorites!')
    }
  }
  return <div className="container" style={{
    minHeight: 600,
  }}>

    <div
      className="card text-white" style={{
      backgroundColor: 'rgba(0,0,0,0.75)',
    }}
    >
      <div className="card-header">
        {/*back btn text */}
        <button
          onClick={() => props.back()}
          className="btn btn-link text-white"
        >
          {'<'} Back
        </button>
        <h3 className="card-title text-center">{props.data && props.data.name}

          <button
            onClick={() => handleLike(!liked, props.data)}
            className={`ml-3 btn-outline-light btn rounded-circle ${liked
              ? 'active'
              : ''}`}
          >
            {/*favourite icon*/}
            <i
              className={`bi bi-heart-fill ${liked ? 'text-danger' : ''}`}
            ></i>
          </button>
        </h3>

      </div>
      <ul className="nav justify-content-center bg-success">
        <li className="nav-item" onClick={() => getEvent()}>
          <div
            className={`nav-link text-white ${tab === 1
              ? 'font-weight-bold'
              : ''}`}
            aria-current="page"


          >Events</div>
        </li>
        <li className="nav-item" onClick={() => getArtist()}>
          <div
            className={`nav-link text-white ${tab === 2
              ? 'font-weight-bold'
              : ''}`}
          >Artist/Teams</div>
        </li>
        <li className="nav-item" onClick={() => getVenue()}>
          <div
            className={`nav-link text-white ${tab === 3
              ? 'font-weight-bold'
              : ''}`}
          >Venue</div>
        </li>

      </ul>
      <div className="card-body">
        <div className="tab-content">
          {tab === 1 && <Events ref={eventRef}></Events>}
          {tab === 2 && <Teams ref={artistRef}></Teams>}
          {tab === 3 && <Venue ref={venueRef}></Venue>}
        </div>
      </div>
    </div>
  </div>
})
const Events = forwardRef((props, ref) => {
  const [data, setData] = useState(null)
  useImperativeHandle(ref, () => ({
    getRefData: () => data,
    getData: async(id) => {
      const data = await fetch('http://localhost:3001/api/detail?id=' + id)
      .then(res => res.json())
      setData(data)
    },
  }))
  const ShareOnFaceBook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${data.url}`)
  }
  const ShareOnTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?url=${data.url}`)
  }
  return data && <div
    className="tab-pane fade show active"
    id="events"
    role="tabpanel"
  >
    <div className="row">
      <div className="col-md-6 text-center">
        <div className="form-group">
          <label htmlFor="date" className={'h5 text-success'}>Date</label>
          <div id="date">
            {data.dates.start.localDate}
          </div>
        </div>
        <div className="form-group">
          <label
            className={'h5 text-success'}
            htmlFor="artist"
          >Artist/Teams</label>
          <div id="artist">
            {data._embedded?.attractions?.map((attraction, idx) => {
              return <span key={attraction.id}>{attraction.name} {
                (!(idx == 0 && idx == data._embedded.attractions.length - 1)) && (idx != data._embedded.attractions.length - 1)
                  ? ' | '
                  : ''}
                </span>
            }) || ''}
          </div>
        </div>
        <div className="form-group">
          <label className={'h5 text-success'} htmlFor="venue">Venue</label>
          <div id="venue">
            {data._embedded.venues[0].name}
          </div>
        </div>
        <div className="form-group">
          <label className={'h5 text-success'} htmlFor="genres">Genres</label>
          <div id="genres">
            {
              data.classifications.map((classification) => {
                return <div key={classification.segment.id}>
                  {getClass(classification)}
                </div>
              })
            }
          </div>
        </div>
        <div className="form-group">
          <label className={'h5 text-success'} htmlFor="price">Price
            ranges</label>
          <div id="price">
            {
              data.priceRanges?.map((priceRange) => {
                  return <div key={priceRange.id}>{priceRange.min} - {priceRange.max}</div>

                },
              ) || ''
            }
          </div>
        </div>
        <div className="form-group">
          <label className={'h5 text-success'} htmlFor="status">Ticket
            status</label>
          <div id="status">
            {
              data.dates.status.code === 'onsale'
                ? <span className={'btn btn-success'}>On sale</span>
                : data.dates.status.code === 'offsale'
                  ? <span className={'btn btn-danger'}>Off sale</span>
                  : data.dates.status.code === 'rescheduled' || data.dates.status.code === 'postponed'
                    ? <span className={'btn btn-warning'}>Rescheduled</span>
                    : <span className={'btn btn-dark'}>Cancelled</span>
            }
          </div>
        </div>
        <div className="form-group">
          <label className={'h5 text-success'} htmlFor="buyTicket">Buy ticket
            at</label>
          <div id="buyTicket">
            <a
              href={data.url}
              target={'_blank'}
              className={'btn btn-link'}
            >Ticketmaster</a>
          </div>
        </div>
      </div>
      <div className="col-md-6 text-center">
        <img
          className={'w-100'} src={
          data.seatmap?.staticUrl
        } alt="Venue map"
        />
      </div>
    </div>
    <div className="row text-center">
      <div className="col-md-12 ">
        <span className={'mr-1'}>Share on:</span>
        <i
          className="bi bi-facebook text-primary mr-1"
          style={{
            width: '20px',
            height: '20px',
          }}
          onClick={ShareOnFaceBook}
        ></i>
        <i
          style={{
            width: '20px',
            height: '20px',
          }} className="bi bi-twitter text-info" onClick={ShareOnTwitter}
        ></i>
      </div>
    </div>
  </div>

})
const Teams = forwardRef((props, ref) => {
  const [data, setData] = useState(null)
  const [current, setCurrent] = useState(0)
  useImperativeHandle(ref, () => ({
    getData: async(eventData) => {
      if (!eventData) return
      const names = eventData._embedded?.attractions.map((attraction) => attraction.name) || []
      //encoded
      const datas = await Promise.all(names.map(async(name) => {
        return await fetch('http://localhost:3001/api/artist?artist=' + name)
        .then(res => res.json())

      }))
      setData(datas)
    },
  }))
  const ShareOnSpotify = (artist) => {
    window.open(`https://open.spotify.com/artist/${artist.id}`)
  }
  return data && data[current]?.artists ? <div
      className="tab-pane fade show active"
      id="artist-teams"
      role="tabpanel"
    >
      <div className="row p-4">
        {data.length > 1 && <div className="col-2 align-items-center">
          {/*  left Arrow*/}
          <button
            onClick={() => setCurrent(((current - 1) < 0
              ? (data.length - 1)
              : (current - 1)) % data.length)}
            className="btn btn-link"
          >
            <span className={'bi bi-caret-left'}></span>
          </button>
        </div>}

        <div className="col-8">
          {
            data[current].artists.items.slice(0, 1).map((artist) => {
              return <div className="col-12 text-center" key={artist.id}>
                <div className="row text-center align-items-center">
                  <div className="col-md-3">
                    <img
                      src={artist.images[0].url}
                      alt="Artist avatar"
                      className={'rounded-circle w-75'}
                    />
                    <p id={'artistName'} className={'h4 text-success'}>
                      {artist.name}
                    </p>
                  </div>
                  <div className="col-md-3">
                    <div className={'h5 text-success'}>Popularity</div>
                    <ProgressRing
                      percent={
                        artist.popularity
                      }
                    ></ProgressRing>
                  </div>
                  <div className="col-md-3">
                    <div className={'h5 text-success'}>Followers</div>
                    <div
                      style={{ height: 60, lineHeight: '60px' }}
                      className={'font-weight-bold'}
                    >
                      {
                        artist.followers.total.toLocaleString()
                      }
                    </div>
                  </div>
                  <div className="col-md-3">
                    <div className={'h5 text-success'}>Spotify Link</div>
                    <div
                      className={'font-weight-bold h5 text-success'}
                      style={{ marginTop: '30px' }}
                    >
                      <span
                        onClick={() => ShareOnSpotify(artist)}
                        className={'bi bi-spotify text-success'}
                      ></span>
                    </div>
                  </div>
                </div>

              </div>
            })
          }

          <div className={'col-12 mt-4'}>
            <div className={'h5 text-success'}>Album featuring
              in {data[current].artists.items[0].name}</div>
          </div>
          <div className="col-12">
            <div className="row text-center">
              {
                data[current].albums.items.slice(0, 3).map(album =>
                  <div className="col-md-4">
                    <img
                      className={'w-100'}
                      src={album.images[0].url}
                      alt="Album 1"
                    />
                  </div>)
              }
            </div>
          </div>
        </div>
        {
          data.length > 1 && <div className="col-2 align-items-center">
            {/*  right Arrow*/}
            <button
              onClick={() => setCurrent((current + 1) % data.length)}
              className="btn btn-link"
            >
              <span className={'bi bi-caret-right'}></span>
            </button>
          </div>
        }
      </div>
    </div>
    : <div className="container">
      <div className="row justify-content-center">
        <div className="col-md-10">
          <div className="alert alert-warning" role="alert">
            No music related artist details to show
          </div>
        </div>
      </div>
    </div>
})

const Venue = forwardRef((props, ref) => {
    const [data, setData] = useState(null)
    const [showMap, setShowMap] = useState(false)
    const [showOpeningMore, setShowOpeningMore] = useState(false)
    const [showGeneralMore, setShowGeneralMore] = useState(false)
    const [showChildMore, setShowChildMore] = useState(false)
    const [hasOpeningMore, setHasOpeningMore] = useState(false)
    const [hasGeneralMore, setHasGeneralMore] = useState(false)
    const [hasChildMore, setHasChildMore] = useState(false)
    const openingRuleRef = useRef(null)
    const generalRuleRef = useRef(null)
    const childRuleRef = useRef(null)

    useImperativeHandle(ref, () => ({
      getData: async(venue) => {
        const d = await fetch('http://localhost:3001/api/venue?keyword=' + venue)
        .then(res => res.json())
        setData(d)
        setTimeout(() => {
          openingRuleRef && openingRuleRef.current && openingRuleRef.current.scrollHeight > 48 && setHasOpeningMore(
            true)
          generalRuleRef && generalRuleRef.current && generalRuleRef.current.scrollHeight > 48 && setHasGeneralMore(
            true)
          childRuleRef && childRuleRef.current && childRuleRef.current.scrollHeight > 48 && setHasChildMore(
            true)
        })
      },
    }))
    return data &&
      <div className="tab-pane fade show active" id="venue" role="tabpanel">
        <div className="row">
          <div className="col-md-6 text-center">
            <div className="form-group">
              <label htmlFor="name" className={'h5 text-success'}>Name</label>
              <div id="name">
                {
                  data._embedded.venues[0].name
                }
              </div>
            </div>
            <div className="form-group">
              <label
                htmlFor="address"
                className={'h5 text-success'}
              >Address</label>
              <div id="address">
                {data._embedded.venues[0].address.line1}, {data._embedded.venues[0].city.name}, {data._embedded.venues[0].state.name}
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="phoneNumber" className={'h5 text-success'}>Phone
                number</label>
              <div id="phoneNumber">
                {
                  data._embedded.venues[0]?.boxOfficeInfo?.phoneNumberDetail || 'N/A'
                }
              </div>
            </div>
          </div>
          {data._embedded.venues[0]?.boxOfficeInfo?.openHoursDetail &&
            <div className="col-md-6 text-center">
              <div className="form-group">
                <label htmlFor="openingHour" className={'h5 text-success'}>Opening
                  hours</label>
                <div
                  id="openingHour" style={
                  showOpeningMore ? { maxHeight: 'none' } : {
                    maxHeight: '3rem',
                    overflow: 'hidden',
                  }
                } ref={openingRuleRef}
                >
                  {
                    data._embedded.venues[0]?.boxOfficeInfo?.openHoursDetail || 'N/A'
                  }
                </div>
                {hasOpeningMore && <div
                  onClick={
                    () => {
                      setShowOpeningMore(!showOpeningMore)
                    }
                  } className={'text-center btn btn-link'}
                >
                  {
                    showOpeningMore ? 'Show less' : 'Show more'
                  }
                  <span
                    className={'bi bi-caret-' + (showOpeningMore
                      ? 'up'
                      : 'down')}
                  ></span>
                </div>}
              </div>
              {data._embedded.venues[0]?.generalInfo?.generalRule &&
                <div className="form-group">
                  <label htmlFor="generalRules" className={'h5 text-success'}>General
                    rules</label>
                  <div
                    id="generalRules" style={
                    showGeneralMore ? { maxHeight: 'none' } : {
                      maxHeight: '3rem',
                      overflow: 'hidden',
                    }
                  } ref={generalRuleRef}
                  >
                    {
                      data._embedded.venues[0]?.generalInfo?.generalRule || 'N/A'
                    }
                  </div>
                  {hasGeneralMore && <div
                    onClick={
                      () => {
                        setShowGeneralMore(!showGeneralMore)
                      }
                    } className={'text-center btn btn-link'}
                  >
                    {
                      showGeneralMore ? 'Show less' : 'Show more'
                    }
                    <span
                      className={'bi bi-caret-' + (showGeneralMore
                        ? 'up'
                        : 'down')}
                    ></span>

                  </div>}
                </div>}
              {data._embedded.venues[0]?.generalInfo?.childRule &&
                <div className="form-group">
                  <label htmlFor="childRule" className={'h5 text-success'}>Child
                    rule</label>
                  <div
                    id="childRule" style={
                    showChildMore ? { maxHeight: 'none' } : {
                      maxHeight: '3rem',
                      overflow: 'hidden',
                    }
                  } ref={childRuleRef}
                  >
                    {
                      data._embedded.venues[0]?.generalInfo?.childRule || 'N/A'
                    }
                  </div>
                  {hasChildMore && <div
                    onClick={
                      () => {
                        setShowChildMore(!showChildMore)
                      }
                    } className={'text-center btn btn-link'}
                  >
                    {
                      showChildMore ? 'Show less' : 'Show more'
                    }
                    <span
                      className={'bi bi-caret-' + (showChildMore
                        ? 'up'
                        : 'down')}
                    ></span>

                  </div>}
                </div>}
            </div>}
        </div>
        <div className="row">
          <div className="col-md-12 text-center">
            <button className="btn btn-danger" onClick={() => setShowMap(true)}>
              <i className={'bi bi-google'}>Show venue on Google Maps</i>
            </button>
          </div>
        </div>
        {showMap && <MapModal
          lng={
            data._embedded.venues[0].location.longitude
          }
          lat={
            data._embedded.venues[0].location.latitude

          }
          handleClose={() => setShowMap(false)}
        ></MapModal>}
      </div>
  },
)

const MapModal = ({ lng, lat, handleClose }) => {
  return (
    <div
      className="modal d-block"
      style={{ overflow: 'initial' }}
      id="mapModal"
      role="dialog"
      aria-labelledby="mapModalLabel"
    >
      <div className="modal-dialog" role="document">
        <div className="modal-content">
          <div className="modal-header">
            <h5
              className="modal-title"
              style={{ color: '#000' }}
              id="mapModalLabel"
            >Event Venue</h5>
            <button
              type="button"
              className="close"
              data-dismiss="modal"
              aria-label="Close"
              onClick={handleClose}
            />
          </div>
          <div className="modal-body" style={{ height: '400px' }}>
            {typeof window !== 'undefined' && (
              <GoogleMapReact
                bootstrapURLKeys={{ key: gmAPI }}
                yesIWantToUseGoogleMapApiInternals
                defaultCenter={{ lat: +lat, lng: +lng }}
                defaultZoom={14}
              >
                <Marker lat={+lat} lng={+lng} />
              </GoogleMapReact>
            )}
          </div>
          <div className="modal-footer justify-content-start">
            <button
              onClick={handleClose}
              type="button"
              className="btn btn-secondary"
              data-dismiss="modal"
            >Close
            </button>
          </div>
        </div>
      </div>
    </div>

  )
}

const Marker = () => <div className="marker ">
  <i
    className="bi bi-geo-alt-fill text-danger"
    style={{ fontSize: '24px' }}
  ></i>
</div>
